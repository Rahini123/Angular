export const environment = {
  production: true,
  outbound_project_name : 'TicketManager'
};

