export interface Agent {
  agent_id: number
  firstName: string,
  lastName: string,
  email: string,
  title: string,
  phoneNumber: number,
  mobileNumber: number,
  address: string,
  timeformat: string,
  level: string
}
