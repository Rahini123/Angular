export interface NewGroupAgents
{
    groupAgentId : number;
    groupAgentName : string;
    groupAgentDescription : string;
    businessFunction : string;
    ticketAssignment : string;
    unassignedTicketTime : string;
    agents :number[];
}