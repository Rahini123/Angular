export interface ticket {
    id: number;
    from_Address: string;
    to_Address : string;
    emailCC:string;
    subject: string;
    ticketNo: string;
    mailBody: string;
    status : string;

  }