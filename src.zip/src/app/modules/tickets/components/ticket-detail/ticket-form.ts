export interface formfield{
  customFields:FormFieldJson[];
  
}
export interface FormFieldJson
{
  label:string;
  value:string;
}