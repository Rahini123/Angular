
export interface sendReplyMail
{
    id : number,
    from_Address : string,
    to_Address : string,
    subject : string,
    mailBody : string
}