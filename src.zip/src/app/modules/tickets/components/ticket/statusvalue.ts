interface statusvalue {
    ticketNo: string,
    status:string
   
}