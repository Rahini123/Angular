

export interface Activeuser{
 id: number,
is_Active: string;
name: string;
}

