export interface User {
  id: number;
  username: string;
  name : string;
  email: string;
  userRoles: string;
  password: string;
  roles : any;
  ids : number[];
}
