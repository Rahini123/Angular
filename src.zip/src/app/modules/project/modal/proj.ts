export interface Project {
    projectId: number;
    projectDescription: String;
    projectActivity: String;
  }