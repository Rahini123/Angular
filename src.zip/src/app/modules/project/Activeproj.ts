export interface Activeproj{

    projectId: number,

    projectActivity: string;

   projectName: string;

   }