export interface ActiveClient{

    clientId: number,

    clientActivity: string;

   clientName: string;

   }