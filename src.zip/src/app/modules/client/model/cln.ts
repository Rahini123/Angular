export interface Client {
    clientId: number;
    clientName: string;
    clientDescription:string;
  }