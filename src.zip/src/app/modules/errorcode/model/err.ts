export interface Error {
    error_id: number;
    error_code: string;
    error_name: string;
    error_description: string;
  }