export class LoginPayload {
    usernameOrEmail!: string;
    password!: string;
    isSuperUser: string = 'N';
  }
  